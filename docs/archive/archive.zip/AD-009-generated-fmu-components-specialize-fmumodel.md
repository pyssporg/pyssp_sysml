---
id: AD-009
title: Generated FMU components specialize FmuModel
summary: A synthesized component that receives fmu_meta is marked ':> FmuModel', and the generated file declares the marker locally.
date: 2026-11-20
status: accepted
layers: [architecture, implementation]
state: 02-architecture/fmu-metadata.md
artifacts:
  - src/pyssp_sysml2/sysml/generate.py
supersedes: []
superseded_by: []
related: [AD-005, AD-008]
---

## Context

`generate sysml` recovered an SSD component's implementation as a local
`fmu_meta` container, but the synthesized part definition carried no role
marker. The dialect treats a locally declared `fmu_meta` as an export unit, so
it requires `:> FmuModel`; without the marker a recovered model is rejected and
the exported text has no self-contained declaration for the marker.

## Decision

When a component receives `fmu_meta`, append `FmuModel` to the part
definition's existing specializations without reordering them. Synthesize a
local `part def FmuModel;` when the marker is absent, so the generated file
parses without the core include. A component without metadata, including a
nested system, stays unmarked.

## Rationale

The explicit marker states the definition's role instead of inferring it from
the presence of an attribute, and it is what the dialect validates. Appending
keeps authored supertypes and their order. Declaring the marker locally keeps
the recovered document self-contained, matching how the generator already
declares the metadata and parameter vocabulary it synthesizes.

## Alternatives Considered

- Mark every synthesized component with `:> FmuModel`: claims an FMU role for
  components that carry no FMU metadata.
- Require the core include for recovered text: the generated file would no
  longer parse on its own and the include is not part of the generated model.
- Replace the specialization list with `FmuModel`: loses an authored base and
  changes order.
- Keep inferring the role from `fmu_meta`: the marker stays implicit and the
  new dialect rule rejects the model.

## Consequences

- Positive: recovered components carry the role the dialect expects, generated
  text declares the marker it uses, and existing bases stay in order.
- Negative: recovered documents gain one local marker definition and a
  `:> FmuModel` clause that a reviewer must accept.
- Deliberate non-change: components without metadata and nested systems remain
  unmarked; golden `.ssd`, `.ssv`, and `.ssm` artifacts are unaffected.

## Verification

`tests/test_roundtrip.py` and `tests/test_fmu_metadata.py` assert the generated
marker and local declaration; the full suite (`python3 -m pytest -q`) and
`ruff check src tests` cover the change. The affected SysML fixtures declare
`part def FmuModel;` locally.

## Review Trigger

`pycps_sysml2` changes the FMU role model, or generation gains a different
marker for synthesized components.
