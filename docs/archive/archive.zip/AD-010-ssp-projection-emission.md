---
id: AD-010
title: SSP emission splits into projection and emission inside one repository
summary: The SSP emitters stop taking pycps objects; a projection stage produces parser-free records and an emission stage writes artifacts, while SSP stays one package until a non-SysML caller exists.
date: 2026-11-22
status: accepted
layers: [architecture, implementation, verification]
state: 02-architecture/generation-pipeline.md
artifacts:
  - src/pyssp_sysml2/projection/
  - src/pyssp_sysml2/emit/
  - src/pyssp_sysml2/artifacts/ssd.py
  - src/pyssp_sysml2/artifacts/ssp.py
  - src/pyssp_sysml2/artifacts/ssv.py
  - src/pyssp_sysml2/artifacts/ssm.py
  - src/pyssp_sysml2/artifacts/analysis.py
  - tests/test_projection_seams.py
supersedes: []
superseded_by: []
related: [AD-004, AD-006]
---

## Context

The SSD writer took a `PartDefinition` and an `Architecture` and re-resolved inheritance with `effective_members` at every helper. The SSV, SSM, and analysis modules had no build seam: each `generate_*` mixed loading, selection, validation, projection, and writing.
Every emitter depended on the parser package's object model, although an SSP artifact carries none of it. A parser-free SSP package beside `pycps_sysml2` would move the artifact family out of this repository and add a second release surface, while no non-SysML caller needs one yet.

## Decision

SSP stays one repository; the seam is internal. `pyssp_sysml2.projection` converts a loaded, post-selection `Architecture` into parser-free records; `pyssp_sysml2.emit` writes SSD, SSV, SSM, the analysis descriptor, and the packaged SSP from those records only.
`artifacts/*` keep the public `generate_*` functions and run load, selection, constraint enforcement, one projection, then emission. Projection is the only SSP-generation code that reads `Architecture`, `PartDefinition`, `PartUsage`, `effective_members`, `resolve_part`, `resolve_port`, `stored_key`, or the parser package's metadata and dialect helpers.
`build_ssd(ssd, model)` accepts a projection record; the pinned `build_ssd(ssd, part_def, architecture)` call remains a thin adapter that projects on the fly.

## Rationale

The artifact is the library boundary (`INFO-029`), and the SSP family is one product with one release; splitting it now would duplicate packaging and versioning for a caller that does not exist. The parser-free model is an internal seam, not a public interchange format.
Projection is the right home for resolution because it already needs the inherited-member view, role metadata, and the parameter dialect. Emission then becomes a pure writer whose seams are testable with plain records, keeping the generated-artifact rule cheap to exercise.

## Alternatives Considered

- **A parser-free SSP package now**: no non-SysML caller, a second release cadence, and a public promise before demand.
- **Leave the emitters typed on the parser**: keeps 13 `effective_members` call sites and blocks any caller that has records but no architecture.
- **Move SSP emission into `pycps_sysml2`**: the parser package would own the artifact family, contradicting `INFO-028` and `AD-004`.
- **Make the projection model public interchange**: freezes internal fields before a consumer needs them; `INFO-029` names the artifact as the boundary.

## Consequences

- Positive: emitters have one input type and no parser import; inheritance is resolved once; each artifact has a named `build_*` seam; `generate_*` signatures are unchanged.
- Negative: one extra internal layer and a copied value rule for fixed multiplicities and formatting in `emit.values`.
- Deliberate non-change: the legacy `build_ssd` call stays public through an adapter; golden `.ssd`, `.ssv`, and `.ssm` bytes are unchanged.

## Verification

`tests/test_projection_seams.py` builds every `build_*` seam from hand-made records with no `.sysml` fixture on disk, reads the artifacts back through `pyssp_standard`, and asserts the emit package imports no `pycps_sysml2` module. `tests/test_golden_artifacts.py` holds the committed bytes; the full suite and `ruff check src tests` cover the refactor.

## Review Trigger

A non-SysML consumer needs to emit an SSD, SSV, SSM, analysis descriptor, or SSP from its own records; then a parser-free SSP package is justified.
