---
id: AD-005
title: Adapt v0.6.0 to pycps_sysml2 0.3.0 Typed Containers
summary: v0.6.0 reads the experiment from a typed DefaultExperiment container, moves flattening to the --flat-connector export option, drops the control-tag plumbing, and leaves the release pin for a follow-up.
date: 2026-11-19
status: accepted
layers: [architecture, implementation, verification, operation]
state: docs/breakdown/02-architecture/control-attributes.md
artifacts:
  - docs/breakdown/02-architecture/control-attributes.md
  - docs/breakdown/02-architecture/ports-and-connections.md
  - docs/breakdown/03-implementation/ssd-artifact.md
  - docs/breakdown/06-evolution/pycps-0-3-repin.md
  - src/pyssp_sysml2/artifacts/ssd.py
  - src/pyssp_sysml2/sysml/generate.py
  - src/pyssp_sysml2/cli.py
  - src/pyssp_sysml2/__init__.py
supersedes: []
superseded_by: []
related: [AD-004]
---

# AD-005: Adapt v0.6.0 to pycps_sysml2 0.3.0 Typed Containers

## Context

`pycps_sysml2` 0.3.0 removed the `pyssp_*` control vocabulary, `ControlAttributes`, `DialectPolicy.control`, and the flat-connector `port def` rule. It added typed experiment containers, `read_experiment`, and `classify_attribute`. `pyssp_sysml2` read the removed attributes directly, so it could not import the new dialect.

## Decision

On 2026-11-19, v0.6.0 made `pyssp_sysml2` a breaking adaptation: SSD generation reads the experiment container and keeps the 0/3600 fallbacks; flattening became the keyword-only `flat_connector` export option and `--flat-connector` CLI flag; control-tag plumbing was removed; SysML synthesis emits a local `DefaultExperiment` container and nothing for flattening.

## Rationale

Special data is recognized by container type, never by attribute name, so the dialect owner stays the only place naming a marker or rule. Flattening changes artifact connector names but not the model, so an export option expresses it without a second dialect. The fallbacks preserve behaviour for documents with no experiment.

## Alternatives Considered

- Re-declare the removed tags locally as a compatibility shim: rejected; it would create a second marker naming rule outside the dialect owner.
- Keep flatness as a model attribute under a new name: rejected; it is an artifact naming choice, deliberately retired.
- Read a missing container as an error: rejected; it would break every model that never declared an experiment.

## Consequences

- Positive: the package imports and runs against the 0.3.0 dialect, with one owner for every marker.
- Positive: the same document exports with and without flattened connector names.
- Negative: 0.6.0 is breaking for models that still write a `pyssp_*` attribute; they now fail with a migration error.
- Negative: `pyproject.toml` still pins the v0.2.0 wheel, so a clean install is broken until the re-pin (`IMP-017`).
- Negative: an SSD-to-SysML-to-SSD loop no longer recovers flattened naming unless the caller passes `flat_connector=True`.

## Verification

`python3 -m pytest -q` reports 404 passed, 1 skipped, and the two pre-existing failures (`test_pyssp_generate_ssd_cli_accepts_two_architecture_flags`, `test_generate_ssd_merges_core_definitions_on_request`); `ruff check src tests` is clean. `tests/test_generate_sysml.py` proves the generated container loads back through `pycps_sysml2` with the core definitions and regenerates the same start and stop time. `tests/test_flat_connector.py` proves both export styles from one document, and `tests/test_generate_ssd.py` pins the migration errors.

## Review Trigger

Revisit when `pycps_sysml2` 0.3.0 is published and the `pyproject.toml` pin moves to it (`IMP-017`), or when a consumer needs flattened naming without passing the option.
