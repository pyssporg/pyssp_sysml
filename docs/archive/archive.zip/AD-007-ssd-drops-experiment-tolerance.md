---
id: AD-007
title: SSD drops the experiment tolerance
summary: SSP 2.0's DefaultExperiment has no tolerance attribute, so the SSD writer emits only startTime and stopTime.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 03-implementation/ssd-artifact.md
artifacts:
  - src/pyssp_sysml2/artifacts/ssd.py
supersedes: []
superseded_by: []
related: [AD-005, AD-006]
---

## Context

`pycps_sysml2` now carries an optional `tolerance` on the shared
`DefaultExperiment` container because FMI 2.0 defines it. The SSD writer reads
the same container, but SSP 2.0's `DefaultExperiment` has no tolerance element
or attribute.

## Decision

`generate ssd` maps the container's `startTime` and `stopTime` (0 and 3600 when
no container exists) and never maps `tolerance`. The value is dropped, not
stored in a project-specific attribute or another element.

## Rationale

Writing tolerance into the SSD would emit XML the SSP schema does not define;
inventing an extension would create dialect vocabulary this package does not
own. The container stays the FMI carrier, and the SSP artifact stays standard.

## Alternatives Considered

- Emit a custom SSD attribute: non-standard output and a second vocabulary.
- Refuse a model whose experiment authors tolerance: blocks a valid model that
  also targets FMI.

## Consequences

- Positive: one container serves both domains, and the SSD remains valid SSP.
- Negative: the tolerance is lost in the SSP direction; this is a documented
  fidelity limit, not a full round trip.

## Verification

`tests/test_generate_ssd.py` and `tests/test_golden_artifacts.py` pin the
emitted default experiment through the golden SSD; the writer calls
`set_default_experiment` with start and stop only.

## Review Trigger

SSP adds a tolerance attribute to `DefaultExperiment`.
