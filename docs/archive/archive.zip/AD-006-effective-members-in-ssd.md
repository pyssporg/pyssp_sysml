---
id: AD-006
title: SSD generation reads effective members
summary: SSD and preflight resolve inherited members through pycps_sysml2, while the SSV writer and SysML synthesis stay declared-only.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/model-structure.md
artifacts:
  - src/pyssp_sysml2/artifacts/ssd.py
  - src/pyssp_sysml2/artifacts/preflight.py
supersedes: []
superseded_by: []
related: [AD-004, AD-005]
---

## Context

`pycps_sysml2` resolves specialization on demand and leaves the IR
source-faithful. This package had to choose, per artifact path, whether to read
that effective view or the declared members.

## Decision

SSD generation, preflight, and parameter-interface synthesis read
`pycps_sysml2.model.effective.effective_members`: an inherited subpart makes a
definition a system, and an inherited port or interface member is emitted like a
declared one. The SSV writer and SysML synthesis stay declared-only, and no
inheritance metadata enters an SSP artifact. An unknown or wrong-kind supertype
is skipped silently by the shared resolver; the SSP side inherits that gap.

## Rationale

The SSD describes the deployed structure, so a component must export the members
that actually reach a connector. The SSV and generated SysML are flat interchange
surfaces; pushing inheritance into them would invent a representation that SSP
and the minimal SysML synthesis do not define.

## Alternatives Considered

- Flatten inherited members into every artifact: the SSV would carry names the
  source never declared, and generated SysML would lose the authored split.
- Ignore inheritance in the SSD too: an inherited subpart would silently become a
  leaf component with the wrong interface.

## Consequences

Positive: the SSD matches the effective structure, and the flat artifacts stay
flat. Negative: a model relying on inherited set values gets no SSV value from
them, and the unknown-supertype gap carries into SSD generation.

## Verification

The `generate-ssd` inheritance fixture pins the component/system split and the
inherited connectors; the golden artifact compares byte-for-byte.

## Review Trigger

SSP gains an inheritance representation, or a consumer needs inherited set values
flattened into the SSV.
