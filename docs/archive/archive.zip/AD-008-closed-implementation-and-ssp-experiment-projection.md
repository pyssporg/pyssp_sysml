---
id: AD-008
title: implementation is closed and the SSD keeps only the SSP experiment fields
summary: pyssp_sysml2 validates implementation against the four ssd:Component values and projects only startTime and stopTime into the .ssd.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/fmu-metadata.md
artifacts:
  - src/pyssp_sysml2/artifacts/ssd.py
supersedes: []
superseded_by: []
related: [AD-005, AD-007]
---

## Context

SSP 2.0.1 closes `ssd:Component/@implementation` to four values, while the shared
vocabulary carried a free string and the SSD writer copied it through.
`pycps_sysml2` also split the experiment by disposition: `DefaultExperiment` now
carries the SSP `startTime` and `stopTime`, and `Experiment` adds the FMI
`stepSize` and `tolerance`.

## Decision

The SSD writer maps `implementation` to `Component/@implementation` unchanged,
and the metadata check accepts only `any|ModelExchange|CoSimulation|ScheduledExecution`.
The writer copies only `startTime` and `stopTime` from the experiment container;
`stepSize` and `tolerance` are never emitted or stored in a project attribute.
`source` and `implementation` remain `ssd:Component` attributes, not
`fmiModelDescription` fields.

## Rationale

An unchecked implementation or an extra experiment field would emit XML the SSP
schema does not define; inventing an extension would create dialect vocabulary
this package does not own. The container stays the FMI carrier and the SSP
artifact stays standard.

## Alternatives Considered

- Pass any implementation string through: emits schema-invalid XML.
- Emit `stepSize` or `tolerance` as custom SSD attributes: a second vocabulary.
- Refuse a model whose experiment authors FMI fields: blocks a valid model that
  also targets FMI.

## Consequences

- Positive: one container serves both standards, the `.ssd` stays valid SSP,
  and a bad implementation is rejected when metadata is read.
- Negative: the two FMI experiment fields are lost in the SSP direction; an
  author targeting both must accept that documented fidelity limit.
- Deliberate non-change: the names `FmuMetadata`, `FmuModel`, and `fmu_meta`
  stay, even though they describe an FMI model packaged as an SSP component.

## Verification

`tests/test_fmu_metadata.py` and `tests/test_generate_ssd.py` cover the metadata
surface; `tests/test_golden_artifacts.py` pins the emitted default experiment;
`tests/test_validate_cli.py` pins the implementation mismatch report.

## Review Trigger

SSP revises the `implementation` enumeration or adds experiment fields.
